import{r as e}from"./index-CM7fNVga.js";function r(t){const a=new FormData;return a.append("file",t),e.post("/admin/files/upload",a,{headers:{"Content-Type":"multipart/form-data"}})}export{r as u};
