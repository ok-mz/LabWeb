import{r as n}from"./index-CM7fNVga.js";function o(){return n.get("/lab-info")}function r(t){return n.put("/admin/lab-info",t)}export{o as g,r as u};
